package com.pluralsight

import com.twitter.scalding._
import com.twitter.scalding.ReplImplicits._
import cascading.flow._
import com.twitter.scalding.RichPipe
import cascading.operation.DebugLevel
import com.twitter.scalding.Local
import cascading.flow.FlowDef

package object repl {
  implicit val mode = Local(false)
  implicit val flowDef = new FlowDef
  flowDef.setDebugLevel(DebugLevel.NONE)
  flowDef.setName("pluralsight")
  
  
  def flow ( operation : Unit ) = {
    // Let Cascading do it's thing
    mode.newFlowConnector(config).connect(flowDef).complete
  }
  
  
  val settings: Map[String, String] = Map(
    "io.serializations" -> "org.apache.hadoop.io.serializer.WritableSerialization,cascading.tuple.hadoop.TupleSerialization,com.twitter.chill.hadoop.KryoSerialization",
    "com.twitter.chill.config.configuredinstantiator" -> "com.twitter.scalding.serialization.KryoHadoop",
    "cascading.flow.tuple.element.comparator" -> "com.twitter.scalding.IntegralComparator")

  val config: Config = Config.from(settings)

}