package com.pluralsight.scalding.m1

import com.twitter.scalding._

class SimplePipeline (args : Args) extends Job(args) {

  
  val input = TextLine(args("input"))
  val output = TextLine(args("output"))
  
  input.read
    .mapTo('line -> 'upper) { line : String => line.toUpperCase() }
   	.write(output)
  
}
